@C:\65\course_sql\Exercises.sql
@C:\65\course_sql\CreateOrders.sql
@C:\65\course_sql\CreateOrderDetails.sql
@C:\65\course_sql\CreateProductCatalog.sql
@C:\65\course_sql\InsertProducts.sql
@C:\65\course_sql\bookorder.sql
@C:\65\course_sql\Customer.sql
@C:\65\course_sql\ordercanonical.sql